# FuncoesJuros
API's para cálculo de juros

# SOLUÇÃO (Juros)

* Projeto: **juros.api**
API para realização do cálculo de juros composto, baseado no resultado adquirido da api (juros.api).
Nota:* Apontar o endpoint no arquivo **juros.api > Services > ServicesTaxaJuros**

* Projeto: **juros.api.test**
Nota: projeto de teste

* Projeto: **taxas.api**
API para busca da taxa de juros fixa




